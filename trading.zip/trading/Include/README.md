## All Files


#### Installation Path

\MQL5\Include
